## [1.2.2](https://github.com/elc9aya2ls612j/helix-project-boilerplate/compare/v1.2.1...v1.2.2) (2023-06-29)


### Bug Fixes

* **github:** use double quotes ([d7e285d](https://github.com/elc9aya2ls612j/helix-project-boilerplate/commit/d7e285dbb452617a5166569f91da4cb376548a38))

## [1.2.1](https://github.com/elc9aya2ls612j/helix-project-boilerplate/compare/v1.2.0...v1.2.1) (2023-06-29)


### Bug Fixes

* **github:** create and ignore bak files ([ac087b6](https://github.com/elc9aya2ls612j/helix-project-boilerplate/commit/ac087b61d3e44910d980b0d9e7aead0f2ed83873))

# [1.2.0](https://github.com/elc9aya2ls612j/helix-project-boilerplate/compare/v1.1.0...v1.2.0) (2023-06-29)


### Features

* **github:** populate pull request template ([4ccb759](https://github.com/elc9aya2ls612j/helix-project-boilerplate/commit/4ccb7592a84fdc0d3d234fc4da5bdf94a026ff1d))

# [1.1.0](https://github.com/elc9aya2ls612j/helix-project-boilerplate/compare/v1.0.5...v1.1.0) (2023-06-29)


### Features

* **github:** remove dependencies upon fork, fill in readme ([7e60519](https://github.com/elc9aya2ls612j/helix-project-boilerplate/commit/7e60519c8ea97640bcb064cb3592990989fe10ef))

## [1.0.5](https://github.com/elc9aya2ls612j/helix-project-boilerplate/compare/v1.0.4...v1.0.5) (2023-06-29)


### Bug Fixes

* trigger release ([2c3244f](https://github.com/elc9aya2ls612j/helix-project-boilerplate/commit/2c3244fc181fd900293bbd7e67ab8e68e5d83d5d))
* trigger release ([5ac78b0](https://github.com/elc9aya2ls612j/helix-project-boilerplate/commit/5ac78b07955c0b75a37dfb293a5d616b7bdaffba))
